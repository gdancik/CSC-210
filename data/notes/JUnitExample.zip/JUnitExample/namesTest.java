import static org.junit.Assert.*;

import org.junit.Test;

public class namesTest {

	@Test
	public void testFormatNames() {
		
		String result1 = names.formatNames("Harry", "Styles");		
		assertEquals("testing Harry Styles", "Styles, Harry", result1);
		
		String result2 = names.formatNames("Faheem", "Najm");		
		assertEquals("testing Faheem Najm", "Najm, Faheem", result2);
		
		
	}

	@Test
	public void testGetInitials() {

		String result1 = names.getInitials("Harry", "Styles");		
		assertEquals("testing Harry Styles", "HS", result1);
		
		String result2 = names.getInitials("Faheem", "Najm");		
		assertEquals("testing Faheem Najm", "FN", result2);
		
		
		
	}

}
