// DIRECTIONS: create a JUnit test suite for the formatNames and getInitials
// 		methods. Note that getInitials returns an extra space, which needs to
//       be modified after testing.

// TO CREATE A JUNIT TEST CLASS 
//		(this is already done, but these instructions are provided for completeness):
// 1. Click once on the names.java file in the package explorer to select it
// 2. Select New->JUnit Test Case
// 3. Remove any checkmarks under "Which method stubs would you like to create?"
//    Under "Do you want to add comments", the "Generate comments" option should
//    not be checked. Then click on Next.
// 4. Select the methods for which test stubs should be created. For this example,
//    we will create methods to test the methods formatNames and getInitials.
// 5. Click on Finish, and a JUnit test class will be created.
// 6. Add a descriptive heading to the test class file, and add relevant tests
//    using methods such as assertEquals. Note that your method calls must be
//    preceded with the class name, e.g., names.formatNames.


public class names{

	// returns name in form: last, first
	public static String formatNames(String first, String last) {
		return "FIX formatNames";
	}
	
	// returns the person's initials (with no punctuation) and
	// no spaces
	public static String getInitials(String first, String last) {		
		return "FIX getInitials";
	}
		
	public static void main (String[] args) {
		return;
	}
}
