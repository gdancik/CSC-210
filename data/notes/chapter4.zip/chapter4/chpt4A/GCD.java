// The Greatest Common Divisor (GCD) of two numbers it the largest number that divides
// both without a remainder. 

// Finding the GCD is useful for reducing fractions and plays a key role in encryption methods.
// For example, the GCD of 6 and 15 is 3. Therefore 6/15 can be re-written as (6/3) / (15 / 3), 
// which gives the reduced fraction of 2 / 5.


// Euler's method for finding the GCD takes advantage of the fact that
// GCD(A,B) = GCD(A,R), where R = A % B. (In the implementation below,
// we get the remainder by continually subtracting A - B).  Because of 
// the above property, we can continually subtracting the smaller 
// number from the larger number. When the numbers are equal, we have
// found the GCD.

import java.util.Scanner;
public class GCD {

	
	public static void main(String[] args) {
	      Scanner scnr = new Scanner(System.in);
	      int numA;  // User input
	      int numB;  // User input

	      System.out.print("Enter first positive integer: ");
	      numA = scnr.nextInt();

	      System.out.print("Enter second positive integer: ");
	      numB = scnr.nextInt();

	      System.out.println();
	      System.out.println("Finding GCD(" + numA + ", " + numB + ")");
	      while (numA != numB) { // Euclid's algorithm
	    	  
	         if (numB > numA) {
	            numB = numB - numA;
	         }
	         else {
	            numA = numA - numB;
	         }
	         
	         System.out.println("      = GCD(" + numA + "," + numB + ")");
	      }
	      
	      
	      System.out.println();
	      System.out.println("GCD is: " + numA);
	      
	      scnr.close();
	   }
	}
