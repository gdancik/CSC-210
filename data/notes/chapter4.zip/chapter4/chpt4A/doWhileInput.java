// A program that uses a do..while loop to get a positive number from the user 

import java.util.Scanner;
public class doWhileInput {

  public static void main(String [] args) {
	  
	// Setup scanner to get input from keyboard	
	Scanner scnr = new Scanner(System.in); 

	// declare variables
	int num;

	do {	
		System.out.print("Enter a positive number: ");
		num = scnr.nextInt();
	} while (num <= 0);
		
	System.out.println("You entered the number " + num + ".");
	
	// close the scanner
	scnr.close();
	
  }
}	
