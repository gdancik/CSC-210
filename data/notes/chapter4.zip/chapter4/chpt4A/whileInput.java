// A program that uses a while loop to get a positive number from the user 

import java.util.Scanner;
public class whileInput {

  public static void main(String [] args) {
	  
	// Setup scanner to get input from keyboard	
	Scanner scnr = new Scanner(System.in); 

	// declare variables
	int num = -1; // initialize so that we enter the loop at least once

	while (num <= 0){
		System.out.print("Enter a positive number: ");
		num = scnr.nextInt();
	} 
		
	System.out.println("You entered the number " + num + ".");
	
	// close the scanner
	scnr.close();
	
  }
}	
