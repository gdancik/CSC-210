// A program that demonstrates nested for loops (one for loop inside of another) 

public class nestedFor {

  public static void main(String [] args) {
	  
	  // for each number 1 - 4
	  for (int num = 1; num <= 4; num++) {	
		  
		  // for each character a - c
		  for (char letter = 'A'; letter <= 'C'; letter++) {			  
			  // output number and character 
			  System.out.print(num  + "" + letter + " ");
		  }
		  
		  // Go to the next line
		  System.out.println();
	  }	
  }
}	
