// A program that uses a for loop to iterate through each character in a string

public class forString {

  public static void main(String [] args) {

	
	String s = "hello";

	// For each character in a string :
	// 			Do something with the character
	  	 	  
	// In order to do this in Java, we must iterate over the index values of the string
	// In this case we output each character followed by a blank space
	for (int i = 0; i < s.length(); i++) {
		System.out.print(s.charAt(i) + " ");
	}
	System.out.println();
	
	
  }	
}
