// A program that demonstrates the 'break' statement 
// the break statement causes the program to immediately exit the loop that it is in

import java.util.Scanner;
public class breakDemo {

  public static void main(String [] args) {
	  
	// Setup scanner to get input from keyboard	
	Scanner scnr = new Scanner(System.in); 

	int num, sum = 0;
		
	System.out.println("Enter five positive numbers: ");
	for (int i = 0; i < 5; i++){
		System.out.print("Enter positive number " + (i+1) + ": ");
		num = scnr.nextInt();
		
		if (num <= 0) {
			System.out.println();
			System.out.println("ERROR: the last number you entered was not positive.");
			System.out.print("Only the sum of the first " + i + " numbers ");
			System.out.println("will be calculated.");
			System.out.println();
			break;			
		}
		
		sum = sum + num;		
	}
	
	
	System.out.println("The sum is: " + sum);
	
	// close the scanner
	scnr.close();
	
  }
}	
