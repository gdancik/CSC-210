// a program that demonstrates the concept of scope
// scope refers to the lines in a program where a variable exists
// in general, a variable exists from the line where it is declared until
// the end of the code block that it is declared in
//   (a code block is a set of statements surrounded by braces {} )

public class scope {

  public static void main(String [] args) {
	  
	  // a block of code is any code enclosed within a pair of braces
	  {
		  int x = 2;
		  System.out.println("a variable exists only in the code block where it is declared");
	  }
	 
	  // What happens if you try to change the value of 'x' here?
	  
	  
	  System.out.println();
	 
	  
	 for (int i = 0; i < 3; i++) {
		 System.out.println("i = " + i);
	 }
	  
	 // What happens if you try to output 'i' here?
	 // 	If a variable is declared in the for loop header, it is 'local' to the 'for' loop 
	 // 	(its scope ends when the 'for' loop ends)
			 
  }
}	
