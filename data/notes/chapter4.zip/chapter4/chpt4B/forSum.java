// A program that uses a for loop to find the sum of the numbers 1-100 

public class forSum {

  public static void main(String [] args) {
	  
	int sum = 0;
	for (int number = 1; number <= 100; number++) {
		sum = sum + number;
	}
	
	System.out.println("The sum of the numbers 1-100 is " + sum);
	
	// Can you also find the sum of the even numbers between 1-100?
	
	
  }
}	
