// A program that uses a for loop to output "Hello" a 
// specified number of times

import java.util.Scanner;
public class forDemo {

  public static void main(String [] args) {
	  
	// Setup scanner to get input from keyboard	
	Scanner scnr = new Scanner(System.in); 

	// declare variables
	int numGreetings = 0;

	// prompt user for number of greetings	
	System.out.print("Enter the number of greetings that you want: ");
	numGreetings = scnr.nextInt();
	
	/**************************************************************
	// the code below (commented out) uses a while loop to output 
	// the specified number of greetings
	int count = 1;
	while (count <= numGreetings) {
		System.out.println("Greeting # " + count + ": Hello");
		count++;	
	}
	***************************************************************/
	
	// the code below uses a for loop to output the specified number of 
	// greetings. Note that this 'for' loop is identical in behavior to the
	// 'while' loop above
	for (int count = 1; count <= numGreetings; count++) {
		System.out.println("Greeting # " + count + ": Hello");
	}
	
	// close the scanner
	scnr.close();
	
  }
}	
