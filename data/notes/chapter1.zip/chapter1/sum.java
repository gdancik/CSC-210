// An example program to get two integers from the user, and output
// the sum

import java.util.Scanner; // Enables user input

public class sum {

  public static void main(String [] args) {

	// Setup scanner to get input from keyboard	
	Scanner scnr = new Scanner(System.in); 
	
	// declare variables for storing values
	int num1, num2, total;
	  
   // get the first number from the user
    System.out.print("Enter an integer: ");
    num1 = scnr.nextInt();  // Read next integer from scanner

    // get the second number from the user
    System.out.print("Enter another integer:");
    num2 = scnr.nextInt();  // Read next integer from scanner

    // calculate the total
    total = num1 + num2;
       
    // output the total
    System.out.print("The sum of " + num1 + " and ");
    System.out.println(num2 + " is " + total + ".");
      
    // close the scanner 
    scnr.close(); 
  }
}
