// An example using strings, scnr.nextLine() and scnr.next()
// Compare nextLine() vs. next() by entering your full name at each prompt

import java.util.Scanner;

public class stringDemo {

	public static void main(String[] args) {
		
		Scanner scnr = new Scanner(System.in);		
		String name;
				
		// scnr.nextLine reads in all text until the end of the line (ENTER)
		// if you enter more than one words, all will be read in
		System.out.print("Please enter your name: ");
		name = scnr.nextLine();		
		System.out.println("You entered: " + name);

		// scnr.next reads all text until a space, tab, or newline (ENTER)
		// if you enter more than one words, only the first word will be read in
		System.out.print("Enter your name again: ");
		name = scnr.next();		
		System.out.println("You entered (first word): " + name);

		scnr.close();
		
		return;
							
	}

}
