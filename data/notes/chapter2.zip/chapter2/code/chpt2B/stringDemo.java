// An example using strings, comparing scnr.nextLine() and scnr.next()
// To compare scnr.nextLine() vs. scnr.next() by entering your full name at each prompt

// Important note #1: when you enter information on the keyboard, every keystroke (including newline, or
// '\n', is recorded in the program's input stream. The scanner works by reading values from its 
// current position in the input stream. 

// Important note #2: after reading in input, scnr.nextLine() advances the scanner past the next 
// whitespace character (newline, blank space, or tab), while scnr.next() leaves the scanner BEFORE
// the next whitespace character. This can lead to issues when using scnr.next() followed by 
// scnr.nextLine(). You therefore should never use scnr.nextLine() after already using scnr.next().

// Your instructor will demonstrate what happens when scnr.nextLine() is used after scnr.next()


import java.util.Scanner;

public class stringDemo {

	public static void main(String[] args) {
		
		Scanner scnr = new Scanner(System.in);		
		String name;
				
		// scnr.nextLine reads in all text until the end of the line (ENTER)
		// if you enter more than one word, all words will be read in
		System.out.print("Please enter your name: ");
		name = scnr.nextLine();		
		System.out.println("You entered: " + name);

		// scnr.next reads all text until a space, tab, or newline (ENTER)
		// if you enter more than one word, only the first word will be read in
		System.out.print("Enter your name again: ");
		name = scnr.next();		
		System.out.println("You entered (first word): " + name);
		
	
		scnr.close();
		
		return;
							
	}

}
