// An example using characters
// Note that character values are always surrounded by single quotes

public class charDemo {

	public static void main(String[] args) {
				
		char letter = 'A';
		System.out.println("The letter is " + letter);
				
		// Because character variables are stored internally as numbers,
		// the below statements do not work (The ASCII value of 'A' is 65)
		System.out.print("Two letters in a row (this does not work because the ASCII values of the letter are added): ");
		System.out.println(letter + letter);
		
		// When outputting letters, you must output a string before or in between
		// the letters so that output will be correct
		System.out.print("Two letters in a row: ");
		System.out.println(letter + "" +  letter);
		
		return;
							
	}

}
