// Be careful for integer division!

public class integerDivision {

	public static void main(String[] args) {
		
		int num1 = 5;
		int num2 = 2;
		
		System.out.print("When a quotient involves two integers,");
		System.out.println("the answer will be an integer, with any");
		System.out.print("remainder or number after the decimal point ");
		System.out.println("dropped.");
		
		System.out.println();
		System.out.print("For example, ");
		System.out.println(num1 + " / " + num2 + " = " + num1/num2 + " in Java." );
		
		System.out.println();
		System.out.println("Typecasting can be used to avoid integer division:");		
		System.out.println("value of num1: " + num1);
		System.out.println("(double) num1: " + (double) num1);
		System.out.println("(double) " + num1 + " / " + num2 + " = " + (double) num1/num2 );
		
		System.out.println();
		System.out.println("The mod operator (%) returns the remainder from integer division.");
		
		System.out.print("For example, ");
		System.out.println(num1 + " % " + num2 + " = " + num1%num2 );
		
	}

}
