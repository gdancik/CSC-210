// A constant variable is a variable whose value cannot be change
// The 'final' keyword is used in the declaration of variables that
// are constant. What happens if you try to change the value of 
// FEET_PER_MILE in this program?

import java.util.Scanner;

public class constant {

	public static void main(String[] args) {
		
		// Setup scanner to get input from keyboard	
		Scanner scnr = new Scanner(System.in); 

		final int FEET_PER_MILE = 5280;
		double miles;
		
		System.out.print("Enter the number of miles you have traveled: ");
		miles = scnr.nextDouble();
		System.out.println("");
		System.out.println("You traveled " + miles + " miles.");
		System.out.println("There are " + FEET_PER_MILE + " feet in one mile.");
		System.out.println("You have traveled " + miles * FEET_PER_MILE + " feet.");
		
		scnr.close();
	}

}
