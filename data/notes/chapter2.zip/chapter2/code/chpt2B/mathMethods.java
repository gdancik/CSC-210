// A demonstration of various mathematical methods
// the Math library must be included
import java.lang.Math;

public class mathMethods {

	public static void main(String[] args) {
		
		double number = 3.14;
				
		System.out.println("number = " + number);
		System.out.println("sqrt(num) = " + Math.sqrt(number));
		System.out.println("round up using ceiling = " + Math.ceil(number));
		System.out.println("round down using floor = " + Math.floor(number));
		System.out.println("round in the usual way = " + Math.round(number));
		System.out.println("number squared = " + Math.pow(number, 2));
							
	}

}
