// A variable must be declared before it is used
// In Java, local variables must initialized
//     
// What happens if age is not initialized?

// The max possible value for an int is 2147483647. 
// What happens if age is initialized to a value higher than this?

public class variables {

	public static void main(String[] args) {
		int age = 0;
		System.out.println("You are " + age + " years old.");		
	}
}
