// A variable must be declared before it is used
// It is good practice to initialize all variables!
//    (by Java specifications, the behavior of programs
//    with uninitialized variables can never be known. 
//      - some compilers will use a default value of 0
//      - some compilers (like Eclipse) will give an error   
//     
// What happens if age is not initialized?
// What happens if age is initialized to 4 billion?

public class variables {
	
	public static void main(String[] args) {
		int age = 18;
		System.out.println("You are " + age + " years old.");
		
	}
}
