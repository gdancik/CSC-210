// A demonstration of various data types

public class dataTypes {

	public static void main(String[] args) {
		
		int numInt = 47;
		double numDouble1 = 20.4, numDouble2 = 1.23e-2;
		
		System.out.println("numInt = " + numInt);
		System.out.println("numDouble1 = " + numDouble1);
		System.out.println("numDouble2 = " + numDouble2);
		System.out.println();
		
		char letter = 'A';
		System.out.println("The first letter of the alphabet is: " + letter);
		
		String name = "Joe";
		System.out.println("Your name is " + name + ".");
		
		
	}

}
