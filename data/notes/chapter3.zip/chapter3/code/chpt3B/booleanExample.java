// A program to demonstrate Boolean values

public class booleanExample {

  public static void main(String [] args) {
	  
	  int x = 5;
	  System.out.println("x > 0: " + (x > 0) );
	  System.out.println("x > 5: " + (x > 5) );
	  System.out.println();  
  
	  boolean ILoveJava = true; 
	  System.out.println("I love Java: " + ILoveJava);
	  System.out.println();
	 
	  // use a boolean variable in an 'if' statement
	  boolean positive = x > 0;
	  
	  if (positive) { 
		  System.out.println("x = " + x + " is positive");
	  } else {
		  System.out.println("x = " + x + " is NOT positive");
	  }
	  
  }
}
