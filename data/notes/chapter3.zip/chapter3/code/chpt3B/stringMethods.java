// This program demonstrates three useful string methods:
//   str.indexOf(item) returns the index of the first occurrence of 'item' in 'str',
//		or -1 if the 'item' is not found (item can be a string or character)
//   str.contains(item) returns 'true' if 'item' is found in the string 'str';
//					 otherwise the method returns 'false'					 
// 	 str.replace(findStr, replaceStr) replaces the 'findStr' with the 'replaceStr'
//		in 'str'. The values of 'findStr' and 'replaceStr' can be strings or characters.

public class stringMethods {

	public static void main(String[] args) { 

		String str = "Look at this sentence";		
		System.out.println("str is: " + str);
		System.out.println();

		System.out.println("index of \"at\": " + str.indexOf("at"));
		System.out.println("index of \"hello\": " + str.indexOf("hello"));
		System.out.println();
		
		System.out.println("check whether \"at\" is found: " + str.contains("at"));
		System.out.println("check whether \"hello\" is found: " + str.contains("hello"));
		System.out.println();
		
	
		System.out.println("replacing \"this\" with \"THE\"");
		String updateStr = str.replace("this",  "THE");		
		System.out.println("updated str is: " + updateStr);
		
	}

}
