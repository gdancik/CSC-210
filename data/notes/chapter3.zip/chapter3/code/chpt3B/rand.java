// Random number generation using the Random library
// The nextInt(n) method generates a pseudorandom number between 0 and n-1.

import java.util.Random;

public class rand {
   public static void main (String [] args) {
      
	  // create the random number generator
      Random randGen = new Random();
      
 	  // set the random number seed
	  // Note: if not set, the number of milliseconds since 1/1/1970 is used	  
	  int seedVal = 0;
	  
	  // FIX ME: comment oout hte line below so the sequence of random 
	  // numbers is different each time
      randGen.setSeed(seedVal);

      // Generate a two random numbers between 1 and 100
      int num1 = randGen.nextInt(100) + 1; 
      int num2 = randGen.nextInt(100) + 1;
      System.out.println("first random number: " + num1);
      System.out.println("second random number: " + num2);

      return;
   }
}
