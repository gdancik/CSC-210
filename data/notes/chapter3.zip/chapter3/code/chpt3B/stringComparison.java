// A program that demonstrates how to compare strings
// string1.equals(string2) returns true if string 1 and string2 are
//   exactly the same (and this is case-sensitive)
// string1.equalsIgnoreCase(string2) is the same as above but is not
// 	case sensitive
// string1.compareTo(string2) returns the following:
// 	an integer < 0 if string1 is less than string2 alphabetically
//  an integer > 0 if string1 is greater than string2 alphabetically
//  0 if the two strings are identical

public class stringComparison {

  public static void main(String [] args) {
	  
	String course = "CSC-210";
	System.out.println("course = " + course);
	System.out.println();
	
	boolean csc210 = course.equals("CSC-210");
	System.out.println("course is CSC-210: " + csc210);
	
	boolean csc231 = course.equals("CSC-231");
	System.out.println("course is CSC-231: " + csc231);
	System.out.println();
	
	System.out.println("course is csc-210 (lower-case): " + course.equals("csc-210"));
	System.out.println("course is csc-210 (ignore case): " + course.equalsIgnoreCase("csc-210")); 
	System.out.println();
	
	System.out.println("compareTo CSC-210: " + course.compareTo("CSC-210") );
	System.out.println("compareTo MAT-135: " + course.compareTo("MAT-135") );
	System.out.println("compareTo ART-100: " + course.compareTo("ART-100") );
	
	return;
	
  }
  
  
  
  
}	
