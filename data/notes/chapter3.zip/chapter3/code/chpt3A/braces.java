// Not including braces around if-else statements can lead to logic (or syntax) errors
// Therefore, braces should always be used

public class braces {

  public static void main(String [] args) {	
	int num = 5;

	// You must use braces to group multiple 'if' (true) statements and 'else' (false) statements 
	System.out.println("Correct output using braces:");
	System.out.println("num is " + num);
	
	if (num < 10) {
		System.out.println("num is less than 10");
	}
	else {
		System.out.println("In else...");
		System.out.println("num is NOT less than 10");		
	}

 	System.out.println();

	// Without braces, only the first 'if' and 'else' statements get associated with
	// the if and else, respectively. In this case, "num is NOT less than 10" is
	// not a part of the 'else' statement and is always output
	
	System.out.println("Not using braces leads to a logic error:");
	System.out.println("num is " + num);
	
	if (num < 10) 
		System.out.println("num is less than 10");		
	else 
		System.out.println("In else...");
		System.out.println("num is NOT less than 10"); 	
 
		
  }
  
}
