// This program uses an if-else statement to output whether an integer
// entered by the user is positive, negative or 0.

import java.util.Scanner;

public class if_else {

  public static void main(String [] args) {

	  // Setup scanner to get input from keyboard	
	  Scanner scnr = new Scanner(System.in); 

	  int num;
	  System.out.println("Please enter any integer: ");;
	  num = scnr.nextInt();

	  // if the integer is positive, output that integer is positive,
	  // otherwise if the integer is negative, output that the integer is negative,
	  // otherwise output that the integer entered is zero
	  
	  if (num > 0) {
		System.out.println("The integer " + num + " is positive");
	  } else if (num < 0) {
		  System.out.println("The integer " + num + " is negative");
	  } else {
		  System.out.println("The integer you entered is zero");
	  }

	  scnr.close();
	  
	  return;
  }
  
}


