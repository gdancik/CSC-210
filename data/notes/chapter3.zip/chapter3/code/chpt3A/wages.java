// A program to calculate a person's weekly pay, assuming they get
// time and a half for overtime. Note that the algorithm for this
// calculation requires 'branching', and an 'if-else' statement is used 

import java.util.Scanner; // Enables user input

public class wages {

  public static void main(String [] args) {
	  
	// Setup scanner to get input from keyboard	
	Scanner scnr = new Scanner(System.in); 

	// declare variables
	int hours;
	double gross_pay, rate;
	
	// prompt user for hourly rate and # of hours worked
	System.out.print("Enter the hourly rate of pay: $");
	rate = scnr.nextDouble();
	System.out.print("Enter the number of hours worked (to nearest integer): ");
	hours = scnr.nextInt();
	
	// close the scanner
	scnr.close();
	
	
	// calculate weekly pay, based on whether person works overtime
	if (hours <= 40)  {
		// calculate pay without overtime
		gross_pay = rate*hours;
	} else	{
		// calculate pay with overtime
		gross_pay = rate*40 + 1.5*rate*(hours-40);
	}

	// output the results -- 
	//    Note: System.out.printf is used to format the output)
	//    	%.2f is used to specify 2 decimal places
	//    	%n is used to output a newline character
	System.out.println("Hours = " + hours);
	System.out.printf("Hourly pay rate = $%.2f%n", rate);
	System.out.printf("Gross pay = $%.2f%n", gross_pay);

	return;
  }
}	
