// A 'people' class consists of a collection of 'persons'. 
// Note: the main method of this class is used to demonstrate its functionality

public class people {

	// in this example, an array of 'person' objects is used. However, other collections
	// such as ArrayLists (see Chapter 7 of zyBooks) provide more functionality and 
	// would be preferred
	private person [] p; // an array of person objects
	
	// the constructor initializes the people with first names, last names, and ages
	people(String first[], String last[], int age[]) {
		int size = first.length;
		p = new person[size];
		for (int i = 0; i < size; i++) {
			p[i] = new person(first[i], last[i], age[i]);
		}		
	}
	
	// print the list of people
	public void print() {
		for (int i = 0; i < p.length; i++) {
			p[i].print();
		}
	}

	// FIX ME: add public member method to return the number of people in the list
	
	// FIX ME: add public member method to output individuals that are a given age
	

	public static void main(String[] args) {

		String [] firstNames = {"Tom", "Kate", "Alice", "Zak", "Sara"};
		String [] lastNames = {"Smith", "Jones", "Jensen", "Thompson", "Hendersen"};
		int [] ages = {19,20,19,21,18};
		
		 
		people p = new people(firstNames, lastNames, ages);
		
		// FIX ME: output the number of people stored in 'p', using the appropriate
		// accessor method
		
		p.print();
		System.out.println();
		System.out.println();
		
		// FIX ME: call member function to print individuals who are 19
	
	}

}
