// The RunnerTimes class contains the main method for looking at two runners

public class RunnerTimes {

   public static void main(String[] args) {      
      // User-created object of class type RunnerInfo
	   
	  System.out.println("Create runner1 object");
      RunnerInfo runner1 = new RunnerInfo();

      // display summary based on default values from the constructor
      runner1.summary();
      
      // set the time and distance
      System.out.println("set time and distance for runner 1");
      runner1.setTime(360);
      runner1.setDist(1.2);

      // display summary based on new values
      runner1.summary();

      System.out.println("Runner1's speed in MPH: " + runner1.getSpeedMph());
      System.out.println();
      System.out.println();
      
      // A second object
      System.out.println("create runner2, set time and distance");
      RunnerInfo runner2 = new RunnerInfo();   
      runner2.setTime(200);
      runner2.setDist(0.5);
      System.out.println("Runner2's speed in MPH: " + runner2.getSpeedMph());
            
   }
   
   
   
}

