// person class - each 'person' has a first name, last name, and age

public class Person {

	// private data for each Person
	private String first;
	private String last;
	private int age;
	
	// constructor for Person class
	public Person(String f, String l, int a) {
		first = f;
		last = l;
		age = a;
	}

	// prints information for a person
	public void print() {
		System.out.println(last + ", " + first + "\t" + age);
		
	}
	
	
	// accessor function for age
	public int getAge() {
		return age;
	}
	
	// mutator function	for age
	public void setAge(int a) {
		age = a;
	}
	
	// note: additional accessor/mutator member methods are omitted
	
	// main program to test our class
	public static void main(String[] args) {
				
		Person person = new Person("Jane", "Roberts", 18);
		person.print();
		
		System.out.println();
		System.out.println("Change age to 19: ");
		person.setAge(19);
		person.print();
		System.out.println();

		// FIX ME: print only the age of the person	

	}

}
