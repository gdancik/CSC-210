// person class - each 'person' has a first name, last name, and age

public class person {

	private String first;
	private String last;
	private int age;
	
	public person(String f, String l, int a) {
		first = f;
		last = l;
		age = a;
	}

	public void print() {
		System.out.println(last + ", " + first + "\t" + age);
		
	}
	
	
	// accessor function for age
	public int getAge() {
		return age;
	}
	
	// mutator function	for age
	public void setAge(int a) {
		age = a;
	}
	
	// note: additional accessor/mutator member methods are omitted
	
	// main program to test our class
	public static void main(String[] args) {
		
		person p = new person("Jane", "Roberts", 18);
		p.print();
		
		System.out.println();
		System.out.println("Change age to 19: ");
		p.setAge(19);
		p.print();
		System.out.println();

		// FIX ME: print only the age of the person	

	}

}
