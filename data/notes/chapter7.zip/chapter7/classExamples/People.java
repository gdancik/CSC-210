// A 'people' class consists of a collection of 'persons'. 
// Note: the main method of this class is used to demonstrate its functionality

public class People {

	// in this example, an array of 'person' objects is used. However, other collections
	// such as ArrayLists (see Chapter 7 of zyBooks) provide more functionality and 
	// would be preferred
	private Person [] p; // an array of person objects
	
	// the constructor initializes the people with first names, last names, and ages
	People(String first[], String last[], int age[]) {
		int size = first.length;
		p = new Person[size];
		for (int i = 0; i < size; i++) {
			p[i] = new Person(first[i], last[i], age[i]);
		}		
	}
	
	// print the list of people
	public void print() {
		for (int i = 0; i < p.length; i++) {
			p[i].print();
		}
	}

	public int getNumberOfPeople() {
		return p.length;
	}
	
	// prints information for people who are the given age
	public void printByAge(int age) {
		
		for (int i = 0; i < p.length; i++) {
			Person person = p[i];
			if (person.getAge() == age) {
				person.print();
			}
		}
	}
	

	public static void main(String[] args) {

		String [] firstNames = {"Tom", "Kate", "Alice", "Zak", "Sara"};
		String [] lastNames = {"Smith", "Jones", "Jensen", "Thompson", "Hendersen"};
		int [] ages = {19,20,19,21,18};
		
		 
		People p = new People(firstNames, lastNames, ages);
		System.out.println("The people in our list are:");
		p.print();
		System.out.println();
		
		// FIX ME: output the number of people stored in 'p', using the appropriate
		// accessor method
		
		
		System.out.println();
		System.out.println();
		
		// FIX ME: call member function to print individuals who are 19		
		
	}

}
