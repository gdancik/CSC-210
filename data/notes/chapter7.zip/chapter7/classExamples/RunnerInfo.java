// Introduction to objects and classes, which are constructs holding both data (fields)
// and methods to act on the data

// RunnerInfo is based on the zyBook example, but would probably be more appropriately 
// named 'RaceInfo' or 'RunInfo'. The RunnerInfo class contains a running time (timeRun) 
// and a distances (distRun), and allows a user to set the time and distance, 
// and to calculate the speed in MPH

// Note that RunnerInfo does not have a main method; the main program that uses this 
// class can be found in RunnerTimes.java

public class RunnerInfo {

   // The private internal fields (data) of the class
   private int timeRun;
   private double distRun;
      
   // the constructor is called when a RunnerInfo object is created
   RunnerInfo() {
	   timeRun = 0;
	   distRun = 0;	   
   }
   
   // The public methods of the class
   
   // Set time run in seconds
   public void setTime(int timeRunSecs) {
      timeRun = timeRunSecs;  // timeRun refers to class member
      return;
   }

   // Set distance run in miles
   public void setDist(double distRunMiles) {
      distRun = distRunMiles;
      return;
   }

   public void summary() {
	   System.out.println("Runner's summary ------->");
	   System.out.println("Time run (seconds): " + timeRun);
	   System.out.println("Distance run (miles): " + distRun);
	   System.out.println();
   }
   
   // Get speed in miles/hour
   public double getSpeedMph() {
      // miles / (sec / (3600sec/hr))
      return distRun / (timeRun / 3600.0);
   }
   
}

