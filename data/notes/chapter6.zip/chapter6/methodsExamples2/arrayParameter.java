// This program illustrates whether parameter values can be changed

// In general, changes made to a parameter inside a function do NOT change the value of
// the corresponding argument

// However, changes made to the value of the element of an array parameter will change
// the value of the corresponding argument...

// But changing the array reference (the object assigned to the array parameter) does
// not change the argument

public class arrayParameter {

	// print out the values of the given array
	public static void printArray(int [] x) {
		for (int i = 0; i < x.length; i++) {
			System.out.print(x[i] + " ");
		}
		System.out.println();
	}
	
	// in a method, changing the value of a parameter DOES NOT, in general, 
	// change the value of the corresponding argument
	public static void changeInt(int num) {
		System.out.println("changeInt changes parameter num to 4");
		num = 4;
	}
	
	// in a method, changing a specific element of an array parameter DOES change the 
	// element of the corresponding argument
	public static void changeArrayValue(int x[]) {
		System.out.println("changeArrayValue changes 1st element of array to 4");
		x[0] = 4;
	}

	// in a method, changing the reference (i.e., object stored in) an array parameter
	// does NOT change the corresponding argument
	public static void changeArrayRef(int x[]) {
		System.out.println("changeArrayValue changes the array to one with three 4's");
		
		int [] newArray = {4,4,4};
		x = newArray;
		
	}

	public static void main (String[] args) {
		int arr[] = {1,2,3,4};
		int number = 1;
		
		System.out.println("number is " + number);
		changeInt(number);
		System.out.println("Back in main, number is " + number + " (the argument is not changed)");
		System.out.println();
		
		System.out.print("the array is: ");
		printArray(arr);
		changeArrayValue(arr);
		System.out.print("Back in main, the array is: ");
		printArray(arr);
		System.out.println("\t(an alement of an array argument can be changed)");
		System.out.println();

		System.out.print("the array is: ");
		printArray(arr);
		changeArrayRef(arr);
		System.out.print("Back in main, the array is: ");
		printArray(arr);
		System.out.println("\t(an array argument reference cannot be changed)");
		System.out.println();
		
		return;
	}

}


