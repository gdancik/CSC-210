// This program is a version of the guessing game, where a user must guess a random number
// between 1 and 10. Note the modular design of the program and how easy 'main' is to
// understand

import java.util.Scanner;
import java.util.Random;

public class guessingGameMethods {

	// if a method needs a scanner, declare a static Scanner at top of the class
	static Scanner scnr = new Scanner(System.in);
	
	// generates a random integer in the range a-b (inclusive)
	public static int generateNumber(int a, int b) {
		Random rndGen = new Random();
		int num = rndGen.nextInt(b-a + 1) + a;
		return num;
	}
	
	// prompts the user to guess a number and returns this number
	public static int userGuess() {
		
		System.out.print("Please guess a number: ");
		int num = scnr.nextInt();
	
		return num;
	}
	
	// Gives feedback regarding whether the guess is too high, too low, or correct
	// 		guess -- the user's guess
	//  		num -- the correct value.	
	// This method returns true if the guess is correct, and false otherwise. Note 
	// that we can use a return statement  anywhere in the method, which allows for 
	// shortcuts when dealing with branches.
	public static boolean getFeedback(int guess, int num) {

		// if the guess is correct, we can return true right away
		if (guess == num) {
			System.out.println();
			System.out.println("Your guess is CORRECT! Congratulations!");
			return true;
		}
		
		// if we are here, then guess is not correct, so give appropriate feedback
		// and then return false
		if (guess < num) {
			System.out.println("Your guess is TOO LOW");
		} else if (guess > num) {
			System.out.println("Your guess is TOO HIGH");			
		}
		
		return false;
	}
	
	// the main program
	public static void main (String[] args) {
	
		int guess, correctNum, count = 0;
		boolean isCorrect = false;
	
		// generate random number
		correctNum = generateNumber(1,10);
		
		
		do {
			// get user's guess
			guess = userGuess(); 
			
			// increase counter for number of guesses
			count++; 
			
			// display feedback to user
			isCorrect = getFeedback(guess, correctNum);
			
		// repeat while guess is not correct (i.e., until guess IS correct)
		} while (!isCorrect); 
		
		// display number of guesses and thank the user for playing
		System.out.println("You guessed the correct answer in " + count + " tries.");
		System.out.println("Thanks for playing!");
		
	}

}


