// The scope of a method's parameter only includes the method 
// (we say that the parameter is local to the method)

// A method cannot change the value of an argument that is of a primitive type 
// (e.g., an int, double, etc).

// Question: does the variable 'x' exist in the method? Why or why not?
// Does the output change if we use a variable named 'num' instead of 'x'? 
// 	Why or why not?

public class primitiveTypeParameters {

	// num is local to the method; changing 'num' does not change the value of 
	// the argument (this is true no matter what we call the parameter)
	public static void changeInt(int num) {
		System.out.println("changeInt changes parameter num to 4");
		num = 4;		
	}
	
	
	public static void main (String[] args) {
		int x = 1;
		System.out.println("number is " + x);
		changeInt(x);
		System.out.println("Back in main, number is " + x + " (the argument is not changed)");
		System.out.println();
		
		// What if we did the same thing using a variable named 'num'?
	
		
	}

}


