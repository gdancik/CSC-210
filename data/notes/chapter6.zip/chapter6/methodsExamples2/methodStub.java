// This program gives an example of a method stub, which is a method that is
// not complete but is sufficient so that the rest of the program can be tested.
// In this case, the method 'getPositiveNumber' is a stub that behaves as
// if the user enters the number 3

import java.util.Scanner;

public class methodStub {
	
	// if a method needs a scanner, declare a static Scanner at top of the class
	static Scanner scnr = new Scanner(System.in);
	
	public static int getPositiveNumber() {
			
		// FIX ME: prompt the user to enter a positive number. The user is 
		// repeatedly prompted until a positive number is entered, and the postive
		// number is returned
		
		return 3;
		
	}
	
	
	public static void main (String[] args) {
		
		
		int inputNum = getPositiveNumber();
		System.out.println("The number you entered is: " + inputNum);
		
		return;
	}

}


