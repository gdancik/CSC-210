// This program demonstrates the use of user-defined methods
// How could you modify only the main program to print "Hello" twice?

public class methodDemo {

	// method to output Hello
	public static void printHello() {
		System.out.println("Hello");
	}

	// method to output Goodbye
	public static void printGoodybe() {
		System.out.println("Goodbye");
	}
	
	
	public static void main (String[] args) {

		System.out.println("In main, call the printHello method: ");
		printHello();			
		
		System.out.println();
		System.out.println("In main, call the printGoodbye method:");
		printGoodybe();
		
		return;
	}

}


