// This program gives an example of a user-defined method with two parameters 
// that returns a value

import java.util.Scanner;

public class returnDemo{

	// a method that adds two numbers and returns the sum
	public static int add(int x, int y) {
		int total = x + y;
		return total;
	}
	
	public static void main (String[] args) {

		Scanner scnr = new Scanner(System.in);
		System.out.print("Enter any two integers: ");
		int num1 = scnr.nextInt();
		int num2 = scnr.nextInt();
		
		int sum = add(num1, num2);
		System.out.println("The sum of " + num1 + " and " + num2 + "  is: " + sum);

		// Alternatively, we could call the method in the System.out.println statement
		// System.out.println("The sum of " + num1 + " and " + num2 + "  is: " + add(num1, num2));
		
		scnr.close();
	}
}
