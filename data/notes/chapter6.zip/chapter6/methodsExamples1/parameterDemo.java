// This program gives an example of a user-defined method with a single parameter

public class parameterDemo {

	public static void outputNumber(int num) {
		System.out.println("the number is: " + num);
	}
	
	public static void main (String[] args) {

		// the value 3 is passed to the method parameter 'num'
		outputNumber(3);
		
		// the value of 'x' is passed to the method parameter 'num'
		int x = 4;
		outputNumber(x);
		
	}

}


