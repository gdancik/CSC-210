// This program gives an example of a user-defined method with a single parameter

public class parameterDemo {

	public static void outputNumber(int num) {
		System.out.println("the number is: " + num);
	}
	
	public static void main (String[] args) {

		outputNumber(3);
		
		int x = 4;
		outputNumber(4);
		
		return;
	}

}


