// This program illustrates the initialization behavior of arrays in Java

public class arrayInitialization {

	public static void main (String[] args) {

		// array declaration and explicit initialization of values but not size
		// the size of the array is the number of elements specified 
		int [] x1 = {20,21,22,23};
		
		// alternative declaration of an array with explicit size of 4,
		// followed by initialization
		int [] x2 = new int[4];
		x2[0] = 20;
		x2[1] = 21;
		x2[2] = 22;
		x2[3] = 23;
		
		System.out.println("x1\tx2");		
		for (int i = 0; i < 4; i++) {
			System.out.println(x1[i] + "\t" + x2[i]);
		}
		System.out.println();
		
		
		// The default value of all elements of a numeric array are 0	
		int [] y = new int[4];
		System.out.println("The (default) y values are: ");
		for (int i = 0; i < y.length; i++) {
			System.out.println(y[i]);
		}
		
	}
}


