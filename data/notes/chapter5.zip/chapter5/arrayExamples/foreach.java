// When looking at each element of an array, loop through the index values if
// you need to know the index or if you need to change the value of the array 
// element

// If all you need to do is to access the element, then the 'for each' method
// is preferred.

// This program demonstrates the use of a for each loop to access each element
// of an array

public class foreach {

	public static void main (String[] args) {

		// declare an array of 4 numbers
		int arr[] = new int[4]; // the size of the array is in brackets
		arr[0] = 2;		// initialize the 1st element (at index 0)
		arr[1] = 10;	// initialize the 2nd element (at index 1)
		arr[2] = 1;		// initialize the 3rd element (at index 2)
		arr[3] = 0;		// initialize the 4th element (at index 3)
	

		
		// we use a for loop to access each element in an array by its index
		//System.out.println("The array contains the elements:");
		//for (int i = 0; i < arr.length; i++) {
		//	System.out.println(arr[i]);
		//}
		
		// we can also use a 'for each' array to iterate through each element
		// of the array directly. The code below does the same thing as the 
		// commented out code above
		System.out.println("The array contains the elements: ");
		for (int num : arr) {
			System.out.println(num);
		}
		
						
	}

}


