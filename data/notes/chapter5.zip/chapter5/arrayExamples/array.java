// This program gives an example of an integer array

public class array {

	public static void main (String[] args) {

		// declare an array of 4 numbers
		int arr[] = new int[4]; // the size of the array is in brackets
		arr[0] = 2;		// initialize the 1st element (at index 0)
		arr[1] = 10;	// initialize the 2nd element (at index 1)
		arr[2] = 1;		// initialize the 3rd element (at index 2)
		arr[3] = 0;		// initialize the 4th element (at index 3)
	
		System.out.println("length of array is: " + arr.length);
  
		System.out.println("The 1st element of the array is arr[0] = " + arr[0]);
		System.out.println("The 4th element of the array is arr[3] = " + arr[3]);

		System.out.println();

		
		// we use a for loop to access each element in an array by its index
		System.out.println("The array contains the elements:");
		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i]);
		}
		
		
		// What happens when you reference an index outside of the array?		
		// What kind of error is this?
		
				
	}

}


