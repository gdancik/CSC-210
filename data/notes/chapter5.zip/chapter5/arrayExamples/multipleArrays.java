// This program gives an example of multiple String arrays to store related lists
// (in this case, words and their definitions)

import java.util.Scanner;

public class multipleArrays {

	public static void main (String[] args) {

		Scanner scnr = new Scanner(System.in);
		
		// arrays for words and corresponding definitions
		String [] words = new String[5];
		String [] definitions = new String[5];
		
		words[0] = "variable";  definitions[0] = "references a location in the memory of a CPU which stores a value";
		words[1] = "loop";    	definitions[1] = "a programming structure that can repeat statements multiple times";
		words[2] = "array";  	definitions[2] = "a list of variables/values of the same type";
		words[3] = "int";		definitions[3] = "a variable that stores an integer";
		words[4] = "break";		definitions[4] = "a statement to immediately exit a loop";
		
		String userWord = "word";

		
		// repeat while user has not entered 'q'
		while (!userWord.equals("q")) {
			
			// prompt user to enter a word
			System.out.println();
			System.out.print("Enter a word to look-up or type \'q\' to quit: ");
			userWord = scnr.next();		
					
			// find the definition of the userWord by looking at each word in the dictionary
			boolean wordFound = false;			
			for (int i = 0; i < words.length; i++) {
			
				if (userWord.equals(words[i])) {
					System.out.print(words[i] + " -- ");
					System.out.println(definitions[i]);
					wordFound = true;
					break;
				}
			
			}
		
			if (!wordFound && !userWord.equals("q")) {
				System.out.println("The word " + userWord + " was not found in the dictionary");
			}
		}
		
		System.out.println();
		System.out.println("Have a good day!");
		
		scnr.close();
	}

}


