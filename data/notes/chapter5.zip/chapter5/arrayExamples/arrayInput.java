// Modify this program to read in the specified number of integers from the user,
// then output the numbers in the original and reverse order

import java.util.Scanner;

public class arrayInput {

	public static void main (String[] args) {

		Scanner scnr = new Scanner(System.in);
		System.out.print("How many integers do you want to enter? ");
		int numInts = scnr.nextInt();
		
		// FIX ME: create an integer array of size 'numInts'
		
		
		// FIX ME: prompt the user to enter 'numInts' integers, and store
		// in the array
		
		
		// FIX ME: output the integers in the original order
			
		
		// FIX ME: output the integers in reverse order
				
		
		
		return;
	}

}


