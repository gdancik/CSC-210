// This program gives an example of a 2D array that stores a gradebook.
// A 2D array is similar to a 1D array, but requires both a row index
// and a column index


public class twoDimensionalArray {

	public static void main (String[] args) {

	// declare an integer array of 4 rows (students) 
	// and 3 columns (quiz 1, 2, and 3 per student).
	// Initialize array one row at a time
	int [][]grade = { {91, 92, 93},	
                      {81, 82, 83},
                      {71, 72, 73},
                      {74, 75, 76}
					};
		
	// Use nested for loops to go through each row
	// To go row by row, the outer for loop moves through each row,
	// and the inner for loop moves through each column
	System.out.println("Current gradebook: ");
	for (int i = 0; i < 4; i++) {   // for each student
		
		
		System.out.print("Student " + (i+1) + ": ");	
		for (int j = 0; j < 3; j++) { // for each quiz
			System.out.print(grade[i][j] + " "); // output the student's quiz grade
		}
		System.out.println();
	}

	System.out.println(); 
	System.out.print("Quiz score for Student 3 (row index 2), Quiz 2 (column index 1): ");
	System.out.println(grade[2][1]); 
	
	
	}
}


