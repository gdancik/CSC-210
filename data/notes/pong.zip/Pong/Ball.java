/**********************************************************************
Ball - a class for creating a ball object, which has a color, a position, 
and can move left, right, up, down, randomly, or in the current direction;
and can bounce up/down or left/right
***********************************************************************/

import java.awt.Color;
import java.util.Random;

public class Ball {

	// the (x,y) location of the ball
	int x, y;
	
	// how many pixels does the ball move each step?
	int xmove, ymove;

	Random rnd = new Random();
	
	// the color of the ball
	Color color;
	
	Ball(int x_param, int y_param, Color color_param) {
		
		// set current location and color
		x = x_param;
		y = y_param;
		color = color_param;
		
		// ball is not moving by default
		xmove = 0;
		ymove = 0;
	}
	
	// draw the ball at the current location on the given point panel
	public void draw(GraphicsPanel graphics) {
		graphics.addPoint(x, y, color);
		graphics.repaint();
	}

	public void printXY() {
		System.out.println("(x,y) = " + x + ", " + y);
	}
	
	// set the x and y movement directions
	public void setDirection(int x, int y) {
		xmove = x;
		ymove = y;
	}
	
	// the ball moves in the current direction
	public void move() {
		x = x + xmove;
		y = y + ymove;		
	}
	
	public int getX() {
		return x;
	}
	 
	public int getY() {
		return y;
	}
	
	/****************************
	 * methods for ball movement
	****************************/	
	public void moveLeft() {
		x--;
	}
	
	public void moveRight() {
		x++;
	}
	
	public void moveUp() {
		y--;
	}
	
	public void moveDown() {
		y++;
	}	
	
	public void moveRandom() {
		
		int num = rnd.nextInt(4);
		if (num == 0) {
			moveRight();
		} else if (num == 1) {
			moveLeft();
		} else if (num == 2) {
			moveDown();
		} else if (num == 3) {
			moveUp();
		}		
	}

	/*******************************
	 * methods for "bouncing"
	 ******************************/
	public void bounceUpDown() {	
		ymove = -ymove;		
	}
	
	public void bounceLeftRight() {
		xmove = -xmove;
	}
}
