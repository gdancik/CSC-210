// PointPanel manages the panel of points which are painted to the screen

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JPanel;


/***********************************************************************
* handles graphics (based on the point list and corresponding colors)
************************************************************************/
public class GraphicsPanel extends JPanel {	
    List <Ellipse2D> pointList;
    List <Color> colorList;
    
    private static final long serialVersionUID = 1;
    
    public GraphicsPanel() {    	
        pointList = new ArrayList <Ellipse2D>();
        colorList = new ArrayList <Color>();                
        setBackground(Color.white);
    }
    
    // paints to the screen
    protected void paintComponent(Graphics g)
    {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;        
        
        for(int j = 0; j < pointList.size(); j++)
        {            
            g2.setPaint(colorList.get(j));
            g2.fill(pointList.get(j));
        }        
    }
  
 
    // clears the screen
    public void reset() {
    	pointList.clear();
    	colorList.clear();
    	repaint();
    }

    // adds a point at location (x,y) of the specified colors
    public void addPoint(int x, int y, Color color) {
        Ellipse2D e = new Ellipse2D.Double(x - 3, y - 3, 6, 6);
        pointList.add(e);             
        colorList.add(color);      
    }
    

}
