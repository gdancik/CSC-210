// Paddle - a paddle which can move left or right, and hit or miss a ball

import java.awt.Color;

public class Paddle {

	// the (x,y) position of the middle of the paddle
	private int x, y;
	
	// the width of the paddle (technically, width + 1)
	private int width; 
	
	private int xmove; // if > 0, move to the right; if < 0, move to the left
	
	// the color of the paddle
	private Color color;
	
	Paddle(int x_param, int y_param, Color color_param, int width_param) {
		
		// set current location, color, and width
		x = x_param;
		y = y_param;
		color = color_param;
		width = width_param;
		
		xmove = 1; // will move to the right initially
	}
	
	public void draw(GraphicsPanel graphics) {
		for (int xpos = x - width/2; xpos <= x+width/2; xpos++) {
			graphics.addPoint(xpos, y, color);
		}
		graphics.repaint();
	}

	public int getX() {
		return x;
	}
	 
	public int getY() {
		return y;
	}
	
	public int getXRight() {
		return x + width/2;
	}
	
	public int getXLeft() {
		return x - width/2;
	}
	
	/*********************************
	 * Methods for moving the paddle
	*********************************/
	public void move() {
		if (xmove > 0) {
			moveRight();
		} else if (xmove < 0) {
			moveLeft();
		}
	}
	
	public void moveLeft() {
		x = x - 2;
		xmove = -1;
	}
	
	public void moveRight() {
		x = x + 2;
		xmove = 1;
	}
	
	public void stop() {
		xmove = 0;
	}	
	
	// returns true if the paddle hits the ball
	public boolean hit(Ball b) {			
		if (b.getX() < getXLeft()) return false; // ball to the left, (B -----)
		if (b.getX() > getXRight()) return false;// ball to the right, (----- B)		
		if (Math.abs(b.getY() - y)>1) return false; // ball too high or too low
		
		// if we get to this part, it's a hit!
		return true;
	}
	
	
	public boolean missed (Ball b) {
		if (b.getY() > y) return true;
		return false;
	}
}
