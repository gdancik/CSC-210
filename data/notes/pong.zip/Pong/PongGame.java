/**********************************************************************
 * This is a Basic Pong Game, containing the following objects:
 * a ball, a paddle, and a point panel (which stores the graphical output)
 * 
 * Pong has the following methods:
 * 	addBall - adds a ball to the game
 *  addPaddle - adds a paddle to the game
 *  start - starts the game
 *  updateGame - an action listener that updates the game
 *  
 *  NOTE: this program will not run if the PaintProgram is also loaded, 
 *  because PaintProgram uses a slightly different PointPanel class. Make
 *  sure PaintProgram is removed from Eclipse before running
***********************************************************************/

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.Timer;

/***********************************************************************
* The main class - a PongGame
************************************************************************/
public class PongGame implements ActionListener
{
	static PointPanel pp;		    
    static final int WIDTH = 600;
    static final int HEIGHT = 600;
   
    Ball ball;    
    Paddle paddle;
    Timer timer;
    
    // adds a ball to the pong game at position (x,y)
    public void addBall(int x, int y, Color color) {
    	ball = new Ball(x,y, color);
		ball.setDirection(1,1);
		ball.draw(pp);
    }
    
    // adds a paddle to the pong game at position (x,y)
    public void addPaddle(int x, int y, int width, Color color) {
    	paddle = new Paddle(x,y, color, width);
		paddle.draw(pp);
    }
    
	PongGame() {
		pp = new PointPanel();
												
		// set up the main window (frame)
	    JFrame f = new JFrame();
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);       
        f.setLayout(new BorderLayout());
                                     
        f.getContentPane().add(pp);        
        f.setSize(WIDTH,HEIGHT);
        f.setResizable(false);        		
        f.setLocation(200,100);
        f.setVisible(true);
        
        
        // handle key press
        f.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
            }

            @Override
            public void keyPressed(KeyEvent e) {
                                                       
                int pressed = e.getKeyCode();

                if (pressed == KeyEvent.VK_LEFT) {
                	paddle.moveLeft();
                } else if (pressed == KeyEvent.VK_RIGHT) {
                	paddle.moveRight();
                }
                          
            }
         
            @Override
            public void keyReleased(KeyEvent e) {
            }
        });
            
        
        
	}

	// starts the game - updateGame() is called every 5 milliseconds
	public void start() {
		timer = new Timer(5, updateGame);
    		timer.setRepeats(true);
     	timer.start();
	}
	
	
	// updates the game
	ActionListener updateGame = new ActionListener(){		
	    public void actionPerformed(ActionEvent event){
	    		    	
	    	pp.reset(); 	
	    	    	
	    	// FIX ME #3: move the ball right, or left, or randomly, 
	    	// then delete this
	    	    		    	
	    	
	    	
	    	// FIX ME #4: move the ball (in the current direction)	    	
	    
	    	
	    	// draw the ball
	    	ball.draw(pp);
	    	
	    	// ball bounces to avoid going off screen
	    		    	
	    	if (ball.getY() <= 0 || ball.getY() >= HEIGHT - 20 ) {
	    		// FIX ME #5: ball is too high or low, so bounce up/down
	    		
	    	}	    	
	    	
	    	if (ball.getX() >= WIDTH  || ball.getX() <= 0) {
	    		// FIX ME #6: ball is too far to the left or right, so bounce left/right
	    		
	    	}

	    	if (paddle == null) return;
	    	
	    	paddle.draw(pp);
	    	paddle.move();
	    	
	    	if (paddle.getXRight() >= WIDTH | paddle.getXLeft() <= 0) {
	    		paddle.stop();
	    	}
	    		    
	    	// FIX ME #8: if the paddle hits the ball, the ball should bounce back
	    
	    	
	    	// FIX ME #9: if the paddle has missed the ball, then change the ball
	    	// to a new location and color
	    	
	    }
	};

	
	// the main program
    public static void main(String[] args) {    	       
    	
    	// create a new PongGame
        PongGame pong = new PongGame();
               
        // FIX ME #1: add a ball to the pong game, at position (50,50)        
        
        
        // FIX ME #2: start the pong game  
        
       
        // FIX ME #7: add a paddle to the pong game, at position (295,570)
        // and with a width of 70 pixels        
        
    }

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub	
	}
        
};
       
