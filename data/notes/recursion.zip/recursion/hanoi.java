// Towers of Hanoi game

// Towers of Hanoi is a puzzle that consists of three posts, 
// and a set of disks of different sizes with holes in the middle so that the 
// disks can be stacked on the posts. You start with all disks stacked on one 
// post, ranging from smallest to largest, top to bottom. 

// Objective: Transfer the stack from the post A to post C, using the 
// post B for temporary storage. 

// Rules:
// You can only move one disk at a time 
// You can never place a larger disk on top of a smaller disk.

public class hanoi {
	
	// hanoi - use recursion to solve towers of hanoi by moving the top 'num' disks
	// from the starting to ending post, using an additional temporary post
	// order of posts is: starting post, ending post, temp post
	public static void solveHanoi (int num, char postA, char postC, char postB) {
		
		// base case - do nothing
		if (num <= 0) return;
	   	
	    // move the top (num - 1) disks from postA to postB:		
	    solveHanoi (num-1, postA, postB, postC);
	 
	    // move bottom disk from postA to postC
	    System.out.println("Move disk " + num  + " from " + postA + " to " + postC);
	    
	    // move the (num - 1) disks from postB to postC:
	    solveHanoi (num-1, postB, postC, postA);
	    
	}

	public static void main (String[] args) {
		  solveHanoi (3, 'A', 'C', 'B');
		
	}

}


