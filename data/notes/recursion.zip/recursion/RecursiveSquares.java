/**********************************************************************
 * This program provides a graphic demonstration of recursion
 * In this case, we start with a method (drawSquares) that 
 * draws a single square, and add a recursive method call to 
 * draw a square within a square within a square...
 * 
 * Complete the FIX MEs to complete the program
***********************************************************************/

import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.util.*;
import java.util.List;
import javax.swing.*;

/***********************************************************************
* The main class - a PaintProgram
************************************************************************/
public class RecursiveSquares implements ActionListener
{
	static Canvas canvas;		
    static JButton btnDraw;
    static final int WIDTH = 600;
    static final int HEIGHT = 600;
    
	RecursiveSquares() {
		canvas = new Canvas();
		
		// the main frame
	    JFrame f = new JFrame();
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);       
        f.setLayout(new BorderLayout());
        f.setFocusable(true);
        f.requestFocus();
             
        // the tool panel - includes instructions and tool selection
        JPanel topPanel = new JPanel();
        topPanel.setLayout(new GridLayout(1,1));        
                            	    
    	    btnDraw = new JButton("Draw Squares");
    	    
    	    topPanel.add(btnDraw);
        
        f.add(topPanel, BorderLayout.PAGE_START);                
        f.getContentPane().add(canvas);        
        f.setSize(WIDTH,HEIGHT);
        f.setMinimumSize(new Dimension(WIDTH, HEIGHT));
        f.setMaximumSize(new Dimension(WIDTH, HEIGHT));		
        f.setLocation(200,100);
        f.setVisible(true);
        
        
        // handle key press
        f.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
            }

            @Override
            public void keyPressed(KeyEvent e) {
                char ch = e.getKeyChar();
                if (ch == 'r' || ch == 'R') {
                	canvas.setColor(Color.red);
                } else if (ch == 'b' || ch == 'B') {
                	canvas.setColor(Color.BLUE);
                } else if (ch == 'g' || ch == 'G') {
                	canvas.setColor(Color.GREEN);
                } else if (ch == 'c' || ch == 'C') {
                	canvas.reset();
                } else if (ch == 'd' || ch == 'D') {
                	canvas.setColor(Color.BLACK);                	
                }
            }

                                   
            @Override
            public void keyReleased(KeyEvent e) {
            }
        });
                    
        
       
        
        // handle tool selection
       btnDraw.addActionListener(new ActionListener() {
    	   public void actionPerformed(ActionEvent eventSource) {    		       		  
    		    		       		   
    		  canvas.drawSquares(300, 260, 30);
    		  canvas.repaint();
    		   
    	       f.requestFocus();
    	   }
        });
                
        
	}

    public static void main(String[] args) {    	       
    	// launch program
        RecursiveSquares r = new RecursiveSquares();        
    }

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub	
	}
        
};
       

/***********************************************************************
* handles graphics (based on the point list and corresponding colors)
************************************************************************/
class Canvas extends JPanel {	
    List <Ellipse2D> pointList;
    List <Color> colorList;
    Color color = Color.black;
    Ellipse2D selectedPoint;    
    private static final long serialVersionUID = 1;
    
    // FIX ME: complete this method which will draw concentric
    // squares centered at (x,y) with increasing values
    // of offset = distance from center to each side
    public void drawSquares(int x, int y, int offset) {
		 
    		// FIX ME: if offset > 250, then do nothing
    		// (this is the base case for the recursion)
    	
    	
    		
    		// draw the square
    		for (int i = -offset; i <= offset; i++) {
    			// draw horizontal lines on top and bottom
    			addPoint(x + i, y+offset);
    			addPoint(x + i, y-offset);

    			// draw vertical lines on left and right
    			addPoint(x-offset, y+i);
    			addPoint(x+offset, y+i);
    		}
    		
    		
    		// FIX ME: make a recursive method call to draw the next square, 
    		// increasing offset by 10
    		
    	
    }
    
    
    public Canvas() {    	
        pointList = new ArrayList <Ellipse2D>();
        colorList = new ArrayList <Color>();        
        
        setBackground(Color.white);
    }
  
    
    // paints to the screen
    protected void paintComponent(Graphics g)
    {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;        
        
        for(int j = 0; j < pointList.size(); j++)
        {            
            g2.setPaint(colorList.get(j));
            g2.fill(pointList.get(j));
        }        
    }
  
    // sets the selected color
    public void setColor(Color col) {
    		color = col;
    }
  
    // clears the screen
    public void reset() {
    		pointList.clear();
    		colorList.clear();
    		repaint();
    }

    // adds a point at location (x,y)
    public void addPoint(int x, int y) {
        Ellipse2D e = new Ellipse2D.Double(x - 2, y - 2, 4, 4);     
        pointList.add(e);             
        colorList.add(color);      
    }
     
}