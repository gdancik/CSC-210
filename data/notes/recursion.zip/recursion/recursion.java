// A recursive method is a method that calls itself
// The flow of control in a recursive method follows the 
// same principles for any method. When a function call ends,
// the flow of control of a program returns to where the method
// was originally called    

// All recursive methods must have a 'base case' causing the recursion
// to end

public class recursion {

	// returns the factorial of num, num! = num*(num-1)*(num-2)*....*1
	public static int factorial(int num) {
		if (num == 0) {
			return 1;
		}
		return num*factorial(num-1);
	}

	

	public static void main (String[] args) {
		
		int x = 4;		
		int f = factorial(x);					
		System.out.println("The factorial of " + x + " is " + f);
	
	}

}


