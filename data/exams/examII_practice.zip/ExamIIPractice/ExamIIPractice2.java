// Exam II Practice Problems

import java.util.Scanner;
public class ExamIIPractice2 {
	
	public static void main(String[] args) {

		double nums[] = {2,7,6,10};
		
		// (1) Write a statement that outputs the 1st element of the array
		
		// (2) Write a statement that changes the 3rd element of the array to 0
		
		// (3) Write a statement or statements that swaps the 2nd and 3rd number of the array
	
		
		// Consider the following arrays which store the grades for 4 students
		String names[] = new String[4];
		double grades[] = new double[4];
		 
		names[0] = "Smith, Mary"; 		grades[0] = 87.3;
		names[1] = "Jones, Peter";		grades[1] = 92.5;
		names[2] = "Palmer, Bill";		grades[2] = 82.0;
		names[3] = "Green, Becky";		grades[3] = 94.7;
		
		// (4) Write statements that use a loop to print out all the grades in the form
		// Smith, Mary -- 87.3
		
		// (5) Write statements that use a loop to print out the names (and only the names)
		// of the individuals having an A (a 90 or higher)
		
		// (6) Write statements that prompts the user to enter someone's last name, and then
		// outputs that person's grade
		
		Scanner scnr = new Scanner(System.in);
		
		
		// Consider the following Tic-Tac-Toe board, with 1 representing an 'X', -1
		// representing an 'O', and a 0 representing a blank space (displayed as '-')
		int [][] board = { {1,0,1}, 
						   {0,1,0},
						   {1,0,1}								
						};
		
		
		// (7) Use nested for loops to display the board, which will look like this:
		//		X - X
		//		- 0 -
		//		X - X
		
		// (8) Use nested for loops to change all X's to O's and all O's to X's
		
	}
	

}
