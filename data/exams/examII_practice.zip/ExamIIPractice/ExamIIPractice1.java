// Exam II Practice Problems
import java.util.Random;

public class ExamIIPractice1 {
	
	public static void main(String[] args) {
		
		
		// Consider the following output:
		// Hello 5
		// Hello 10
		// Hello 15
		// Hello 20
		
		// (1) Use a for loop to output the above text
		
		
		// (2) Use a while loop to output the above text
		
		
		// Now consider the following output:
		// 5-4-3-2-1 
		
		
		// (3) Use a for loop to output the above text
		
		
		// (4) Use a while loop to output the above text

		
		// (5) Use a do while loop to generate an even random number between 1 and 20
		//     In order to do this, a number between 1 and 20 is generated, and the 
		//     process is repeated until the number generated is even

		Random randGen = new Random();
				

		// (6) How many times does the loop below output "Hello"?
		// (Note: you should be able to determine this by looking at the code, but 
		// you can uncomment the code to see if you are correct)
		
		/*
		int num = 5;
		while (num >= 0) {
			System.out.println("hello");
			num--;			
		}
		*/
		
		// (7) In the loop above, what condition should be used to output "Hello" 5 times?
				
	}
}
