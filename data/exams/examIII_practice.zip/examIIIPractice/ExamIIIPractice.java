// Exam II Practice Problems
import java.util.Scanner;

public class ExamIIIPractice {
	
	
	public static void outputNumbers(int x, int y) {
		System.out.println("The numbers are " + x + " and " + y + ".");
	}
	
	
	// combines (concatenates) two strings, separated by a space
	public static String combine(String str1, String str2) {
		return str1 + " " + str2;
	}
	
	
	public static void main(String[] args) {
		
		Scanner scnr = new Scanner(System.in);
		
		// (1) Call the 'outputNumbers' method to output the numbers 5 and 17.
		
		// (2) Call the 'combine' method to create the string "Hello World", which is
		// stored in the String object 's', and then output the result
		
		// (3) Write a method called 'findLongest' that has two String parameters,
		//  and returns the following: a 1 if the first String is longer than the 
		//  second String; a 2 if the second string is longer, and a 0 if both
		//  Strings are the same length 
		
		//  Prompt the user to enter 2 strings, then use the 'findLongest' method 
		//  and assign the result to an integer variable named 'longer'. 
		//  Then output which string is the longest best on the value of 'longer'.
		
		// (4) Write a method named 'arraysEqual' that has two integer array parameters 
		// and returns true if the two arrays are the same, and false otherwise. The arrays
		// are the same if they are the same length and all integer elements are the same. 
		
		// (5) Create a Unit Testing program to test the methods in (3) and (4). 
		// For the 'findLongest' method, test that the method works with the 
		// following Strings: "Hi" and "Bye";  "Hello" and "World"; "Hello" and "Hi"
		// For the 'firstCharEqual' method, test that the method works with the
		// following Strings: "Hi" and "Hello"; "Hi" and "hello"
		
		// (6) Write a method called 'minmax' that has two integer array parameters,
		// named 'array' and 'result'. The method calculates the minimum and maximum 
		// values of 'array', and stores the results in the first and second element 
		// of 'result', respectively.
        
        // (7) Write a method named 'reverse', which reverses the elements of an integer array.
        // For example, if the array {1,3,9} was passed to the method; the array will be
        // changed to {9,3,1}. Note that there is a public static 'reverse' method that 
        // is part of the ArrayUtils class, which can be used to reverse the order of
        // elements in an array. However, that method cannot be used for this problem.
		
		scnr.close();
		return;
				
	}
}
