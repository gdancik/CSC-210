// Exam I Practice Problems

import java.util.Scanner;

public class ExamIPractice2 {
	
	public static void main(String[] args) {

		// Setup scanner to get input from keyboard	
		Scanner scnr = new Scanner(System.in); 

		
		int x = 3, y = 2;
		
		// The mathematical average of x and y is equal to (x+y) / 2.
		// Write a statement or statements that outputs the average
		// of x and y
		
		
		int age;
		String name;
		char gender;
		
		
		// Write a statement that declares a constant integer variable named 
		// VOTING_AGE which is equal to 18.
		
		// Write a statement that prompts the user to enter his/her name, and then
		// reads this string into the variable 'name'

		
		// Write a statement that prompts the user to enter his/her age, and then
		// reads this integer into the variable 'age'
		
		// Write a statement that prompts the user to enter his/her gender (M/F), and 
		// then reads this character into the variable 'gender'. Note that 'gender' is a 
		// character variable
		
		
		// Write a statement or statements that outputs the user's name and age, and whether 
		// that person is male or female. For example, if the user entered 
		// Joe Smith, 19, and M, 
		// you would output: Joe Smith is a 19 year old male.
		// Note: gender is M for male, and F for female. Any other value should
		// result in an output indicating that the gender is not specified.
		
		
		// Write a statement or statements that that outputs the following. 
		// If the user is old enough to vote (i.e., is at least VOTING_AGE), then
		// output that the individual can vote (e.g., "Joe Smith can vote"). Otherwise if
		// the user is NOT old enough to vote, then output the number of years 
		// required before the person can vote. For example, if the user Joe Smith was
		// 16, you would output "Joe Smith can vote in 2 year(s)"
		
		
		
	}
}
