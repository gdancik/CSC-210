// Exam I Practice Problems
// Note: This program contains additional code in order to check your random number generation
// This code contains some concepts that will be discussed later, and can be ignored for now.
// Follow the FIX ME's to complete the practice for the first exam

import java.util.Scanner;
import java.util.Random;

// IGNORE: these are used for checking the random values
import java.util.Set;
import java.util.HashSet;


public class ExamIPractice3 {
	
	public static void main(String[] args) {

		// create the random number generator
	    Random randGen = new Random();
	    
		// Setup scanner to get input from keyboard	
		Scanner scnr = new Scanner(System.in); 

		// use these variables in FIXME's below
		int randVal = 0;
		String line, capital;

		// IGNORE -- the object below is used to check your random number generation
		 Set<Integer> values = new HashSet<Integer>();
					
		// IGNORE: the 'for' loop will execute 1000 times, in order to check the random number generation
		for (int i = 0; i < 1000; i++) { 
			
			// FIX ME: write a statement or statements that generate a random number between 
			// 1 and 4, and assigns the number to randVal
			
            // add code here
			
			// IGNORE -- record the random value for checking purposes
			values.add(randVal);
		}
		
		
		// IGNORE -- checks that your random numbers are between 1-4
		System.out.println("===== checking for random numbers between 1-4");
		checkValues(values, 1, 4);

		values.clear();

		// IGNORE: the 'for' loop will execute 1000 times, in order to check the random number generation		
		for (int i = 0; i < 1000; i++) {
			
			// FIX ME: Write a statement or statements that generate a random number between 
			// 10 and 20, and assign the number to randVal
			

            // add code here


			// IGNORE -- record the random value for checking purposes
			values.add(randVal);										
		}
		
		// IGNORE -- checks that your random numbers are between 10-20
		System.out.println("===== checking for random numbers between 10-20");
		checkValues(values, 10, 20);

		
				
		// FIX ME: write a statement or statements that prompt the user to enter a 
		// line of text, which is stored in 'line'
		
		
		
		// FIX ME: write a SINGLE if...else statement that outputs whether or not
		// the line of text contains any of these lower-case words: 
		// "the", "and", "hello"

		
		
		// FIX ME: write a statement that prompts the user to enter the capital of CT, which
		// is stored in the variable 'capital'
		
		
		
		// FIX ME: write a statement that outputs that the user is correct if the previous
		// answer is Hartford (ignore case); otherwise, output "Incorrect"
		
		
		
	}
	
	
	// IGNORE: Below is a method that will check whether your random number generation is correct
	public static void checkValues(Set <Integer> v, int min, int max) {
	
		// output the random numbers that were generated
		System.out.print("You generated the following numbers: ");
		for (int i : v) {
			System.out.print(i + " " );
		}
		System.out.println();;
		
		// check if all numbers in the range were generated
		boolean missing = false;
		for (int i = min; i <= max; i++) {
			if (!v.contains(i)) {
				if (!missing) {
					System.out.print("You did NOT generate the following numbers: ");
					missing = true;
				}
				System.out.print(i + " ");				
			}
		}

		if (missing) System.out.println();
						
		// check if any numbers outside the range were generated
		boolean extra = false;
		for (int i : v) {
			if (i <min || i > max) {
				if (!extra) {
					System.out.print("The following incorrect numbers were generated: ");
					extra = true;
				}
				System.out.print(i + " ");
			}
		}
		
		if (extra) System.out.println();

		// Is user correct, or not?
		if (!missing && !extra) {
			System.out.println("YOU ARE CORRECT!!");
		} else {
			System.out.println("Please try again!");
		}
		System.out.println();
	}
	
}
