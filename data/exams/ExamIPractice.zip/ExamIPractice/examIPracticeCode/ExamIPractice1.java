// Exam I Practice Problems

public class ExamIPractice1 {
	
	public static void main(String[] args) {

		
		// Write a statement that prints the following: This is fun! 
		
		// Write a statement that prints the following: What does "branching" mean?
		
		// Write a statement that prints the following (do not start a new line): 
		//		The number is: 
		
		// Write a statement that declares a variable named 'number' which is 
		// initialized to 43
		
		// Write a statement that outputs the value of the number
		
	}
}
