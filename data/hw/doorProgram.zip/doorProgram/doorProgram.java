/**************************************************************************
 * doorProgram - this program uses a 1-dimensional array to represent
 *  a set of doors that are either closed (0) or open (1). Complete the 
 *  program by following the instructions under the FIX ME comments. 
 *  Note: you may also change the images (but must use png or jpg 
 *  images and these must be saved in the correct folder). 
 *  Note that your program must work correctly if the value of NUM_DOORS 
 *  is changed.
 **************************************************************************/  

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.*;  
  
public class doorProgram implements ActionListener{  
	
	final int NUM_DOORS = 4;
	JButton [] buttons = new JButton[NUM_DOORS];
	int [] doors = new int [NUM_DOORS];		
	ImageIcon doorImg;
	ImageIcon openImg;
			 
	JFrame frame = new JFrame();
	JPanel buttonPanel = new JPanel();	
	
	doorProgram(){  
		
		
		
		/* FIX ME #1: set the path to the folder containing the pictures */		
		String path = "pics/";
		
		// open the images
		String doorStr = path + "door.png";
		String openStr = path + "open.png";
						
		doorImg = new ImageIcon(doorStr);	
		if (doorImg.getImageLoadStatus() != java.awt.MediaTracker.COMPLETE) {
			System.out.println("ERROR - door picture could not be loaded");
			System.exit(-1);
		}			
		Image img = doorImg.getImage();  
		Image newimg = img.getScaledInstance(400 / NUM_DOORS, 400 / NUM_DOORS,  java.awt.Image.SCALE_SMOOTH);  
		doorImg = new ImageIcon( newimg );
		
	
		openImg = new ImageIcon(openStr);
		if (openImg.getImageLoadStatus() != java.awt.MediaTracker.COMPLETE) {
			System.out.println("ERROR - open picture could not be loaded");
			System.exit(-1);
		}
		img = openImg.getImage();  
		newimg = img.getScaledInstance(400 / NUM_DOORS, 400 / NUM_DOORS,  java.awt.Image.SCALE_SMOOTH);  
		openImg = new ImageIcon( newimg );
		
		// create the buttons
		for (int i = 0; i < NUM_DOORS; i++) {				
				buttons[i] = new JButton("");
				buttons[i].setName("" + (i+1)); 													
				buttons[i].setIcon(doorImg);
				buttons[i].setMargin(new Insets(1, 1, 1, 1));				
				buttons[i].addActionListener(onClick);
				buttonPanel.add(buttons[i]);
		}
			   	    
	    buttonPanel.setLayout(new GridLayout(1,NUM_DOORS));   	 
	    frame.setSize(1000,400);  
	    frame.setLocation(200,200);	    
        frame.add(buttonPanel);
        frame.setResizable(false);	    
	    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);	 
	    frame.setVisible(true);
	    frame.setFocusable(true);

	    // handle key press
	    frame.addKeyListener(new KeyListener() {
	        @Override
	        public void keyTyped(KeyEvent e) {
	        }

	        @Override
	        public void keyPressed(KeyEvent e) {
	            char ch = e.getKeyChar();
	            System.out.println("key pressed: " + ch);
	            
	            /* FIX ME #3: if the user presses a 'c', then close all
	             * the doors by setting each element of the doors array
	             * to 0; otherwise if the user presses 'o', open all
	             * the doors by setting each element of the doors array
	             * to 1. Note that the number of doors is stored in
	             * NUM_DOORS
	             */
	            
	            
	            
	           	
				// Refresh the screen after updating (DO NOT REMOVE THIS STATEMENT!)
	            refresh();
	        }

	        @Override
	        public void keyReleased(KeyEvent e) {
	        }
	    });
			  	    
	    refresh();    
	    
	}

	
	// refreshes the screen
	void refresh() {
		for (int i = 0; i < NUM_DOORS; i++) {									
				if (doors[i] == 1) {					
					buttons[i].setBackground(Color.black);
					buttons[i].setIcon(openImg);								    							   
				} else if (doors[i] == 0){
					buttons[i].setBackground(Color.blue);
					buttons[i].setIcon(doorImg);
				}
		}	
	}
	
	

	public static void main(String[] args) {  
		doorProgram dp = new doorProgram();    
	}


	@Override
	public void actionPerformed(ActionEvent e) {	
	}
	
	
	ActionListener onClick = new ActionListener() {

		public void actionPerformed(ActionEvent e)
		{
					
			JButton btn = (JButton) e.getSource();
			int selectedNum = Integer.parseInt(btn.getName());
			
			System.out.println("selected door #" + selectedNum);
			
			/* FIX ME #2: open/close the selected door
			 * if the selected door is closed (i.e., the corresponding element of the 
			 * doors array is 0) then open the door (i.e., change the corresponding
			 * element to 1). If the selected door is open (the corresponding element is 1),
			 * then close it (change the corresponding element to 0). Note that
			 * the number of doors is stored in NUM_DOORS.			 			
			 */				
			
			
			
			
			// Refresh the screen after updating (DO NOT REMOVE THIS STATEMENT!)
			refresh();
			
			// give focus back to frame so it can respond to keypresses (DO NOT REMOVE THIS STATEMENT!)
			frame.requestFocus();
		}
	};
	
	
	
}

