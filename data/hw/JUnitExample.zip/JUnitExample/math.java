// This class has simple mathematical methods for adding, subtracting and multiplying numbers.
// The latter two methods are stubs and need to be completed

// Unit testing is a framework for independently and individually testing small programming 
// units such as methods. To prevent logical errors, methods should only be used after they
// are sufficiently tested. Unit testing, once set up, ensures that methods can be quickly
// tested to ensure that subsequent changes do not introduce logic errors into the code

// Unit tests for the below methods are found in mathTest.java.




public class math {

	// returns the sum of x and y
	public static int add(int x, int y) {		
		return x + y;
	}
	
	// subtracts 'y' from 'x' and returns the difference
	public static int subtract(int x, int y) {
		return -1;
	}
	
	// returns the product of x and y
	public static int multiply(int x, int y) {
		return -1;
	}
	
	
	public static void main (String[] args) {
	
		return;
	}
}
