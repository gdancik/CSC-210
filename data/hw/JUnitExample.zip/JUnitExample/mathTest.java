// unit tests for our 'math' class

// Running this script will perform unit tests for each @Test method

// Several methods are useful for testing (the message is optional in all cases): 
// assertEquals(message, expected, actual) FAILS with message if the expected 
// 		value is NOT equal to the actual value
// assertTrue(message, condition) FAILS with message if the condition is not true
// assertFalse(message, condition) FAILS with message if the condition is not false
// fail(message) will FAIL with the given message

// Note: to use the assert functions, you will need to add the JUnit library to build path.
// This is most easily done by hovering over the import statement, selecting Fix project setup, 
// and clicking OK to add the JUnit library to the build path

import static org.junit.Assert.*;
import org.junit.Test;

public class mathTest {

	@Test
	public void testAdd() {
		int m = math.add(3, 4);
		assertEquals("adding 3 and 4:", 7,m);	
	}

	@Test
	public void testSubtract() {
		int answer = math.subtract(2, 6);
		assertEquals("subtracting 6 from 2: ", -4, answer);		
	}

	@Test
	public void testMultiply() {
		int answer = math.multiply(3, 4);
		assertEquals("multiplying 3 and 4: ", 12, answer);		
	}

	
}
