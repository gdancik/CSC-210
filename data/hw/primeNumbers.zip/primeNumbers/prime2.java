/**********************************************************************
*   prime2 -- Add Java code to output all of the prime numbers between
*   2 and 100.  Note that a prime number is an integer greater than 1 
*   whose only factors are 1 and itself. 
**********************************************************************/
 
public class prime2 {
    
  
   public static void main(String[] args){
	   
	   int number;
	   
	   
	   // FIX ME: output all prime numbers between 2 and 100
	   
	   // For each number between 2 - 100 
	   
	   // 		if the number is prime, then 
	   // 			output it
	   
	  
	   System.out.println();
	   System.out.println("Thank you for running this program!"); 
	   
	   
	  
   }
}
