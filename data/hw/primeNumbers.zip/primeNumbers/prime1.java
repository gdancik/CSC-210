/**********************************************************************
*   prime1 -- Complete the FIX MEs to complete the program which
*   gets a positive integer from the user, and then will determine if
*   the integer entered is a prime number. Note that a prime number 
*   is an integer greater than 1 whose only factors are 1 and itself. 
**********************************************************************/
 
import java.util.Scanner;

public class prime1 {
    
  
   public static void main(String[] args){
	   
	   Scanner scnr = new Scanner(System.in);
	   int number;
	   
	   // FIX ME #1: Continually prompt the user to enter a positive integer greater than 1. 
	   // Repeat until a valid integer is entered 

	   
	   // FIX ME #2: Write code to determine whether or not the value of 'number' is
	   // prime. If so, output that the number is prime, otherwise, output that the number is 
	   // not prime. Hint: The algorithm for checking whether a number 'n' is prime is:
	   
	   // 		(A) for each number 'i' between 2 and 'number-1' (inclusive)
	   //			    if 'number' is evenly divisible by 'i', then 'number' is not prime
	   //			    and you are done.
	   
	   // 		(B) output whether or not the number is prime. Note that if 'number' was 
	   // 			evenly divisible by any of the above numbers, then 'number' is not 
	   // 			prime. Otherwise, 'number' is prime. 

	   

	  
	   System.out.println();
	   	   
	   System.out.println();
	   System.out.println("Thank you for running this program!"); 
	   
	   scnr.close();
	   
	   
	   
	  
   }
}
