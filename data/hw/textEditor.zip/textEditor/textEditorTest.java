// Unit testing for textEditor methods
// Complete the unit tests and complete/modify the textEditor methods

import static org.junit.Assert.*;

import org.junit.Test;

public class textEditorTest {

	@Test	
	public void testGetNumOfNonWSCharacters() {
		
		// FIX ME #1B: test getNumOfNonWSCharacters method, under the following conditions
		// (a) the string contains 0 non-whitespace characters
		// (b) the string contains at least one blank space
		// (c) the string contains at least one newline
		// (d) the string contains at least one tab
		fail("Not yet implemented");
	}
	
	@Test
	public void testGetNumOfWords() {
		int num = textEditor.getNumOfWords("hello world");
		assertEquals("2 words separated by a space", 2, num);
		
		num = textEditor.getNumOfWords("");
		assertEquals("0 words in string", 0, num);
		
		num = textEditor.getNumOfWords("hello     how are\nyou?");
		assertEquals("4 words with multiple spaces and a newline", 4, num);
		
		num = textEditor.getNumOfWords("word1\tword2   \t   word3");
		assertEquals("3 words separated by tabs and extra spaces", 3, num);
				
	}
	
	// FIX ME #3C: test that the correct answer is obtained for the following strings:
	// "line1\nline2\n\nline3\nline4"
	@Test
	public void testSingleSpace() {				
		fail("Not yet implemented");
		
	}

	// FIX ME #3D: test that the correct answer is obtained for the following strings:
	// "line1\nline2\n\nline3\nline4"
	@Test
	public void testDoubleSpace() {
		// FIX ME: test double space method
		fail("Not yet implemented");
	}
	
	@Test
	public void testFindIndices() {
		int indexArray[] = textEditor.findIndices("Hello, look at the book", "person");
		assertArrayEquals("text not found, array is empty", new int[0], indexArray);
		
		indexArray = textEditor.findIndices("Hello, look at the book", "oo");
		int []correctArray = {8, 20};
		assertArrayEquals("text found 2 times", correctArray, indexArray);
	
		indexArray = textEditor.findIndices("Hello, look at the book", "book");
		correctArray = new int[1];
		correctArray[0] = 19;
		assertArrayEquals("text found once at end of string", correctArray, indexArray);
	
		
	}

}
