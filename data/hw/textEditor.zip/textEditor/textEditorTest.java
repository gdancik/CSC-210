// Unit testing for select textEditor methods
// Check that your textEditor methods work by running
// these unit tests. Note that you will need to create the 
// getNumOfNonWSCharacters first.

import static org.junit.Assert.*;

import org.junit.Test;

public class textEditorTest {

	@Test	
	public void testGetNumOfNonWSCharacters() {
		
		int num;
		
		num = textEditor.getNumOfNonWSCharacters("");
		assertEquals("no non-whitespace characters", 0, num);
		
		num = textEditor.getNumOfNonWSCharacters("hi");
		assertEquals("no whitespace", 2, num);
		
		num = textEditor.getNumOfNonWSCharacters("a b c");
		assertEquals("2 blank spaces", 3, num);
		
		num = textEditor.getNumOfNonWSCharacters("testing\n\n\t.    ");
		assertEquals("newlines and tabs", 8, num);
		
		
	}
	
	@Test
	public void testGetNumOfWords() {
		int num = textEditor.getNumOfWords("hello world");
		assertEquals("2 words separated by a space", 2, num);
		
		num = textEditor.getNumOfWords("");
		assertEquals("0 words in string", 0, num);
		
		num = textEditor.getNumOfWords("hi");
		assertEquals("1 word and no whitespace", 1, num);
		
		num = textEditor.getNumOfWords("hello     how are\nyou?");
		assertEquals("4 words with multiple spaces and a newline", 4, num);
		
		num = textEditor.getNumOfWords("word1\tword2   \t   word3");
		assertEquals("3 words separated by tabs and extra spaces", 3, num);
				
	}
	
	@Test
	public void testFindIndices() {
		int indexArray[] = textEditor.findIndices("Hello, look at the book", "person");
		assertArrayEquals("text not found, array is empty", new int[0], indexArray);
		
		indexArray = textEditor.findIndices("Hello, look at the book", "oo");
		int []correctArray = {8, 20};
		assertArrayEquals("text found 2 times", correctArray, indexArray);
	
		indexArray = textEditor.findIndices("Hello, look at the book", "book");
		correctArray = new int[1];
		correctArray[0] = 19;
		assertArrayEquals("text found once at end of string", correctArray, indexArray);
	
		
	}

}
