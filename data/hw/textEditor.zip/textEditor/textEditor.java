/***********************************************************************
 * This is a 'textEditor' program that allows a user to enter text and
 * allows for basic text editor features, including word and character
 * counts, searching (finding), and single- and double spacing.
 * 
 * You may work in groups of up to 3 people on this project.
 * 
 *  (Group) members:
***********************************************************************/

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.BadLocationException;


public class textEditor implements ActionListener, DocumentListener {
	
    JTextArea txtInput;
    JTextField txtFind;
    JLabel lblWordCount, lblCharacterCountAll, lblCharacterCountNWS;

    // FIX ME #1A: Write the method definition for a getNumOfNonWSCharacters method
    // that has a String parameter, and returns the number of non white-space
    // characters in the string
    
     
    // FIX ME #2A: Write the method definition for a method called getNumOfWords that 
    // has a single String parameter, and returns the number of words in the 
    // String. NOTE: the method below is NOT correct, since it does not work  
    // correctly in all cases. In particular, this method should handle the
    // case where there are no words and where there are multiple whitespace
    // characters in a row
    
    public static int getNumOfWords(String str) {
    	
    	int wc = 1;
    	for (int i = 0; i < str.length(); i++) {
    		char ch = str.charAt(i);    		
    		if (Character.isWhitespace(ch)) {
    			wc = wc + 1;
    		}  
    	}    	
    	
    	return wc;    	    	
    }
    

    // FIX ME #3A: Write the method definition for a singleSpace method that 
    // has a single String parameter, replaces each occurrence of "\n\n" with
    // "\n", and returns the updated string. In other words, the method 
    // takes in text and converts each double spaced block of text 
    // to a single-spaced version. Note that str.replace("a", "b") will
    // return a copy of the string 'str' with all occurences of "a" 
    // replaced by "b"

    
    // FIX ME #3B: Write the method definition for a doubleSpace method that 
    // has a single String parameter, and replaces each occurrence of "\n" with
    // "\n\n", and returns the updated string. In other words, the method 
    // takes in text and converts each line break to a double spaced format

    
    // The findIndices method creates and returns an integer array that
    // stores the indices of each occurrence of 'searchStr' in 'userStr'
   
    static int [] findIndices(String userStr, String searchStr) {

    	
    		// split userStr into substrings that are before or after searchStr
    		String []splits = userStr.split(searchStr);  
    		int length = splits.length-1;
    		
    		// if userStr ends with searchStr, add 1 to the length
    		if (userStr.length() > searchStr.length()) {
    			String end = userStr.substring(userStr.length() - searchStr.length());    		
    			if (end.equalsIgnoreCase(searchStr)) {
    				length++;
    			}
    		}
    
    		// fill in the indices array
    		int []x = new int[length];
    		int index = -1;
    		for (int i = 0; i < x.length;i++) {
    			index = userStr.indexOf(searchStr, index+1);
    			x[i] = userStr.indexOf(searchStr, index);
    		}
    		return x;
    }
    	
	textEditor() {
	
		// the main frame
	    JFrame f = new JFrame();
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);       
        f.setLayout(new BorderLayout());
        f.setFocusable(true);

        // set up the top panel
        JPanel topPanel = new JPanel(new GridLayout(1,2));
        
        String header = "<html><br>CSC 210 Text Editor<br>&nbsp;</html>";      
        JLabel headerLabel = new JLabel(header,JLabel.CENTER );
        topPanel.add(headerLabel);
        
        // set up the find panel
        JButton btnFind = new JButton("Find");
        JButton btnClear = new JButton("Clear");
        btnFind.addActionListener(this);
        btnClear.addActionListener(this);
        
        JPanel findPanel = new JPanel(new GridLayout(1,4));
        txtFind = new JTextField();
        txtFind.setHorizontalAlignment(JTextField.CENTER);
        findPanel.add(btnFind);
        findPanel.add(txtFind);
        findPanel.add(btnClear);
        topPanel.add(findPanel);
        
        // set up the the main text area     
        txtInput = new JTextArea();        
		txtInput.getDocument().addDocumentListener(this);
			
		JScrollPane scroll = new JScrollPane(txtInput);
	    scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);

		// set up the bottom panel		
		JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new GridLayout(1,2));
		
		lblWordCount = new JLabel("Word count: 0");
		lblCharacterCountAll= new JLabel("Character count (total): 0");
		lblCharacterCountNWS = new JLabel("Character count (non-white space): 0");
        
		JPanel countPanel = new JPanel(new GridLayout(3,1)); 		
        countPanel.add(lblCharacterCountAll);
        countPanel.add(lblCharacterCountNWS);
        countPanel.add(lblWordCount);        
        bottomPanel.add(countPanel);
                                          
        JButton btnDouble = new JButton("Add Double Spaces");
        JButton btnSingle = new JButton("Remove Double Spaces");
        
        btnDouble.setActionCommand("double");
        btnSingle.setActionCommand("single");
        
        ActionListener spaceListener = new ActionListener() {
     	   public void actionPerformed(ActionEvent e) {    		       		  

     		   JButton btn = (JButton) e.getSource();     		  
     		   String action = btn.getActionCommand();
     		   
     		   String initialStr = txtInput.getText();
     		   String finalStr = initialStr;
     		   
     		   if (action.equals("single")) { 
     			   
     			   // FIX ME #3C: Using the singleSpace method, convert initialStr to
     			   // a single-spaced version that is stored in finalStr
     		     			       		     			   
     		   }else if (action.equals("double")) {     			   

     			   // FIX ME #3D: Using the doubleSpace method, convert initialStr to
     			   // a double-spaced version that is stored in finalStr

     		   }
     		   
     		   // update the text box
     		   txtInput.setText(finalStr);
     		        		   
     	   }
         };
        
         btnDouble.addActionListener(spaceListener);
         btnSingle.addActionListener(spaceListener);
         
                   
        JPanel btnPanel = new JPanel(new GridLayout(1,2));        
        btnPanel.add(btnDouble);
        btnPanel.add(btnSingle);
        bottomPanel.add(btnPanel);
     
        // add all the panels to the frame
        f.add(topPanel, BorderLayout.PAGE_START);                
        f.add(scroll);
        f.add(bottomPanel, BorderLayout.PAGE_END);                
                       
        // specify frame size and position
        f.setSize(700,300);        
        f.setResizable(false);
        f.setLocation(300,100);
        f.setVisible(true);
                              
	}

    public static void main(String[] args) {    	       
    	// launch program
        textEditor t = new textEditor();         
    }

    // method to highlight text from start to stop position
    public void highlight(int start, int stop) throws BadLocationException {
    	
    		txtInput.getHighlighter().addHighlight(start, stop,
                new DefaultHighlighter.DefaultHighlightPainter(Color.yellow));    	    	      
    }
    
    // actionPerformed to handle Find and Clear button clicks
    public void actionPerformed(ActionEvent e) {
    	
    		String btn = ((JButton) e.getSource()).getText();
    	    	
    		if (btn.equals("Find")) {
    	    		
    			String userInput = txtInput.getText();    		    		
    			String strFind = txtFind.getText();
    			if (strFind.equals("")) return;
    		
    		    		
    			// FIX ME #4: Delete the statement below, and replace it with 
    			// a statement that calls the findIndices method, in order to 
    			// determine where 'strFind' occurs in 'userInput'. This method 
    			// will return an integer array containing the indices of where 
    			// 'strFind' occurs in 'userInput'. Use 'index' to store the 
    			// array that is returned by the method.
    		
   
    			int [] index = new int[0];
    		    		

    			
    			
    			// the rest of this method should not be modified
    			
    			// highlight all occurrences based on the index array
    			txtInput.getHighlighter().removeAllHighlights();
    			for (int i = 0; i < index.length; i++) {
    				try {
    			  
    					highlight(index[i],index[i] + strFind.length());
    				} catch (BadLocationException exception) {
    					// do nothing if error
    				}
    			}
    		
    		} else if (btn.equals("Clear")) {    		
    			txtInput.getHighlighter().removeAllHighlights();
    			txtFind.setText("");    		        	    		        	
    		}    	
    }
	
    // method displays the character count, non white-space character count,
    // and word count 
    public void refreshCounts() {
		    	
    	int ccTotal = 0, ccNWS = 0, wc = 0;
    	
    	// the text entered by the user
		String userStr = txtInput.getText();
						
		// FIX ME #0: find the character count of userStr and assign this value to ccTotal
			
		
		// FIX ME #1C: use the getNumOfNonWSCharacters method to count the number
		// of non white-space characters in userStr, and store this value in 
		// ccNWS
		
		
		// FIX ME #2B: use the getNumOfWords method to count the number
		// of words in userStr, and store this value in wc
							
		
		lblCharacterCountAll.setText("Character count (total): " + ccTotal);				
		lblCharacterCountNWS.setText("Character count (non-white space): " + ccNWS);				
		lblWordCount.setText("Word count: " + wc);
	}


	@Override
	public void insertUpdate(DocumentEvent e) {				          	
		refreshCounts();		
	}

	@Override
	public void removeUpdate(DocumentEvent e) {
		refreshCounts();
	}

	@Override
	public void changedUpdate(DocumentEvent e) {
		
	}
	
};
       

