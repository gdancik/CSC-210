// Unit tests for the rectangle class

import static org.junit.Assert.*;

import org.junit.Test;

public class rectangleTest {

	@Test
	public void testArea() {		
		int area = rectangle.area(3,4);
		assertEquals("3x4 rectangle has area of 12: ", 12, area);
		
		area = rectangle.area(3,6);
		assertEquals("3x6 rectangle has area of 18", 18, area);
		
	}

	@Test
	public void testPerimeter() {
		int p = rectangle.perimeter(3, 4);
		assertEquals("3x4 rectangle has perimeter of 14", 14, p);
		
		p = rectangle.perimeter(2, 6);
		assertEquals("2x6 rectangle has perimeter of 16", 16, p);
	}

	@Test
	public void testEqualArea() {
		
		int r1[] = {3,4};
		int r2[] = {6,2};
		int r3[] = {1,2};
		
		boolean e1 = rectangle.equalArea(r1, r2);
		boolean e2 = rectangle.equalArea(r1, r3);
		
		assertEquals("compare 3x4 rectangle to 6x2, areas equal: ", true, e1);
		assertEquals("compare 3x4 rectangle to 1x2, areas equal: ", false, e2);
				
	}

}
