// DIRECTIONS: all methods are stubs. Complete each method and run the unit tests  
//   in rectangleTest.java to test your results

public class rectangle{

	// returns the area of a rectangle with length x and width y
	public static int area(int x, int y) {				
		return -1;
	}
	
	// returns the perimeter of a rectangle with length x and width y
	// (the perimeter is the sum of all sides of the rectangle)
	public static int perimeter(int x, int y) {
		return -1;
	}
	
	// returns true if the areas of the rectangles are equal; otherwise
	// returns false
	// rect1 and rect2 should be arrays of size 2 holding the length
	// and width of each rectangle
	public static boolean equalArea(int [] rect1, int [] rect2) {	
		return true;
	}

	
	public static void main (String[] args) {
	
		return;
	}
}
